#ifndef MIBGROUP_SYSORTABLE_H
#define MIBGROUP_SYSORTABLE_H

#ifdef __cplusplus
extern "C" {
#endif

extern void     init_sysORTable(void);
extern void     shutdown_sysORTable(void);

#ifdef __cplusplus
}
#endif

#endif /* MIBGROUP_SYSORTABLE_H */
