/*
 * module to include the modules
 */
config_require(udp-mib/udpEndpointTable)
config_add_mib(UDP-MIB)
